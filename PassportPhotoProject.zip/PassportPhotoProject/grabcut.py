import numpy as np
import cv2

def main():
	url = 'Archive.徐丽萍.jpg'
	origin_img = cv2.imread(url)
	oritin_img = cv2.flip( origin_img, 1 )
	height, width = origin_img.shape[:2]
	print(width, height)


	param = height // 30

	blurred_img = cv2.blur(origin_img, (5, 5))


	mask = np.zeros(blurred_img.shape[:2],np.uint8)
	bgdModel = np.zeros((1,65),np.float64)
	fgdModel = np.zeros((1,65),np.float64)
	rect = (param,param,width,height)


	cv2.grabCut(blurred_img,mask,rect,bgdModel,fgdModel,5,cv2.GC_INIT_WITH_RECT)
	mask2 = np.where((mask==2)|(mask==0),0,1).astype('uint8')




	# refine with marked picture
	cv2.imwrite('check.jpg', origin_img)
	helper(origin_img)
	newmask = cv2.imread('newmask.jpg',0)

	# white: 255, black: 0
	# foreground: 1, background: 0
	mask[newmask != 255] = 1


	mask, bgdModel, fgdModel = cv2.grabCut(blurred_img,mask,None,bgdModel,fgdModel,5,cv2.GC_INIT_WITH_MASK)
	mask = np.where((mask==2)|(mask==0),0,1).astype('uint8')


	person = origin_img*mask[:,:,np.newaxis]

	background = origin_img - person

	background[np.where((background > [0,0,0]).all(axis = 2))] =[255,255,255]
	final = background + person


	cv2.imwrite('test.jpg', final)
	cv2.imwrite('test_blur.jpg', blurred_img)

	k = cv2.waitKey(0)

	if k==27:
		cv2.destroyAllWindows()




def helper(img):
	height, width = img.shape[:2]
	param = height // 30
	edge_white = width // 15

	mask = np.zeros(img.shape[:2],np.uint8)
	bgdModel = np.zeros((1,65),np.float64)
	fgdModel = np.zeros((1,65),np.float64)
	rect = (param,param,width,height)
	cv2.grabCut(img,mask,rect,bgdModel,fgdModel,5,cv2.GC_INIT_WITH_RECT)
	mask2 = np.where((mask==2)|(mask==0),0,1).astype('uint8')
	person = img*mask2[:,:,np.newaxis]
	background = img - person
	background[np.where((background > [0,0,0]).all(axis = 2))] =[255,255,255]
	final = background + person

	# cv2.rectangle(final, (0, 0), (edge_white, height), (255, 255, 255), -1)
	# cv2.rectangle(final, (width-edge_white, 0), (width, height), (255, 255, 255), -1)
	# cv2.rectangle(final, (edge_white, height-height//8), (width-edge_white, height-height//16), (0, 0, 0), -1)
	cv2.imwrite('newmask.jpg', final)
	return final




main()




















# import numpy as np
# import cv2
# import glob


# def grabcut(img, sure_bg, sure_fg, rect=None, blur=(15,15)):
# 	img = cv2.GaussianBlur(img, blur, 0) 
# 	height, width = img.shape[:2]
# 	param = height // 40

# 	rect = rect or (param,param,width,height)

# 	# get grabcut mask for original image, will have left blank problem
# 	mask = np.zeros((img.shape[:2]),np.uint8)
# 	bgdModel = np.zeros((1,65),np.float64)
# 	fgdModel = np.zeros((1,65),np.float64)
# 	cv2.grabCut(img,mask,rect,bgdModel,fgdModel,5,cv2.GC_INIT_WITH_RECT)
# 	mask2 = np.where((mask==2)|(mask==0),0,1).astype('uint8')

# 	# get grabcut mask for horizontally flip image
# 	flip_img = np.fliplr(img)
# 	flip_mask = np.zeros((flip_img.shape[:2]),np.uint8)
# 	flip_bgdModel = np.zeros((1,65),np.float64)
# 	flip_fgdModel = np.zeros((1,65),np.float64)
# 	cv2.grabCut(flip_img,flip_mask,rect,flip_bgdModel,flip_fgdModel,5,cv2.GC_INIT_WITH_RECT)
# 	flip_mask2 = np.where((flip_mask==2)|(flip_mask==0),0,1).astype('uint8')
# 	mask2f = np.fliplr(flip_mask2)

# 	# OR combine two mask, to avoid left and right shoulder blanks
# 	mask_lr = mask2 | mask2f

# 	# white: 255, black: 0
# 	# foreground: 1, background: 0
# 	mask_lr[sure_bg == 255] = 0
# 	mask_lr[sure_fg == 0] = 1
# 	mask_lr, bgdModel, fgdModel = cv2.grabCut(img,mask_lr,None,bgdModel,fgdModel,5,cv2.GC_INIT_WITH_MASK)
# 	mask_lr = np.where((mask_lr==2)|(mask_lr==0),0,1).astype('uint8')

# 	return mask_lr

# 	# Turn black background into white
# 	person = img*mask_final[:,:,np.newaxis]
# 	background = img - person
# 	background[np.where((background > [0,0,0]).all(axis = 2))] =[255,255,255]
# 	final = background + person

# 	cv2.imshow('image',img)
# 	cv2.imshow('background', background)
# 	cv2.imshow('res', final)

# 	cv2.waitKey(0)
# 	cv2.destroyAllWindows()



# def floodfill(img, floodpoints=None, threshold_sure_bg=220, threshold_sure_fg=190):
# 	# Threshold.
# 	# Set values equal to or above 220 to 0.
# 	# Set values below 220 to 255.
# 	height, width = img.shape[:2]
# 	floodpoints = floodpoints or [(width//10, width//10), (width//10, width - width//10)]
	
# 	th1, im_th1 = cv2.threshold(img, threshold_sure_bg, 255, cv2.THRESH_BINARY_INV);
# 	th2, im_th2 = cv2.threshold(img, threshold_sure_fg, 255, cv2.THRESH_BINARY_INV);
	 
# 	# Copy the thresholded image.
# 	im_floodfill1 = im_th1.copy()
# 	im_floodfill2 = im_th2.copy()
	 
# 	# Mask used to flood filling.
# 	# Notice the size needs to be 2 pixels than the image.
# 	h, w = im_th1.shape[:2]
# 	mask1 = np.zeros((h+2, w+2), np.uint8)
# 	mask2 = np.zeros((h+2, w+2), np.uint8)
	 
# 	# Floodfill from point (point_width, point_height)
# 	for point in floodpoints:
# 		cv2.floodFill(im_floodfill1, mask1, point, 255);
# 		cv2.floodFill(im_floodfill2, mask2, point, 255);
	 
# 	# Invert floodfilled image
# 	im_floodfill_inv1 = cv2.bitwise_not(im_floodfill1)
# 	im_floodfill_inv2 = cv2.bitwise_not(im_floodfill2)
	 
# 	# Combine the two images to get the foreground.
# 	im_sure_bg = cv2.bitwise_not(im_th1 | im_floodfill_inv1)
# 	im_sure_fg = cv2.bitwise_not(im_th2 | im_floodfill_inv2)


# 	return (im_sure_bg, im_sure_fg)

# 	cv2.imshow('bg', im_sure_bg)
# 	cv2.imshow('fg', im_sure_fg)

# 	cv2.waitKey(0)
# 	cv2.destroyAllWindows()





# def main():
# 	test_images = glob.glob("Archive/35.jpg")

# 	# # grabcut test
# 	# for img_name in test_images:
# 	# 	img = cv2.imread(img_name)
# 	# 	# resize if too big
# 	# 	if img.shape[0] > 800:
# 	# 		img = cv2.resize(img, (600, 800), interpolation = cv2.INTER_AREA)
# 	# 	mask = grabcut(img)
# 	# 	person = img*mask[:,:,np.newaxis]
# 	# 	background = img - person
# 	# 	background[np.where((background > [0,0,0]).all(axis = 2))] =[255,255,255]
# 	# 	final = background + person
# 	# 	cv2.imwrite("test" + "/" + img_name.split("/")[1], final)


# 	# # floodfill test
# 	# img = cv2.imread("背景问题/徐丽萍.jpg", cv2.IMREAD_GRAYSCALE)
# 	# if img.shape[0] > 800:
# 	# 		img = cv2.resize(img, (600, 800), interpolation = cv2.INTER_AREA)
# 	# floodfill(img)




# 	for img_name in test_images:
# 		# floodfill the background first
# 		# foreground would be black (rgb value 0)
# 		# background would be white (rgb value 255)
# 		gray_img = cv2.imread(img_name, cv2.IMREAD_GRAYSCALE)
# 		# resize if too big
# 		if gray_img.shape[0] > 800:
# 			gray_img = cv2.resize(gray_img, (600, 800), interpolation = cv2.INTER_AREA)
# 		gray_sure_bg, gray_sure_fg = floodfill(gray_img)

# 		img = cv2.imread(img_name)
# 		# resize if too big
# 		if img.shape[0] > 800:
# 			img = cv2.resize(img, (600, 800), interpolation = cv2.INTER_AREA)
# 		# make floodfill checked background white, by adding pixel values directly
# 		# img = cv2.add(gray_im_out, img)
# 		mask = grabcut(img, gray_sure_bg, gray_sure_fg)
# 		person = img*mask[:,:,np.newaxis]
# 		background = img - person
# 		background[np.where((background > [0,0,0]).all(axis = 2))] =[255,255,255]
# 		final = background + person
		
# 		cv2.imwrite("test" + "/" + img_name.split("/")[1], final)





# main()























